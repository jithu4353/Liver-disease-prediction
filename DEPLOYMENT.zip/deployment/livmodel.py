import pandas as pd 
import numpy as np 

# ML Packages
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.externals import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import train_test_split




df= pd.read_csv("indian_liver_patient.csv")

#changing values 1&2 to )&1 respectively

df['is_patient']=np.where((df.is_patient== int(1)),int(0), df.is_patient)
df['is_patient']= np.where((df.is_patient==int(2)),int(1),df.is_patient)
df['is_patient']=df['is_patient'].apply(pd.to_numeric)

#droping duplicates
df=df.drop_duplicates()

#fill with mean vlaues
mean_value=df['alkphos'].mean()
df['alkphos']= df['alkphos'].fillna(mean_value)

#converting continuos to numerical values
dummy= pd.get_dummies(df['gender'])
df=pd.concat([df,dummy], axis=1)
df=df.drop('gender', axis=1)

#setting target varable
target_name='is_patient'
y=df[target_name]
x=df.drop(target_name, axis=1)

#split the dataset as 80-20

#split into train/ test validation dataset
x_train, x_val, y_train, y_val= train_test_split(x, y, test_size=0.25, random_state=7)

#selecting hyperparameter using gridsearchCV
solver_list = ['liblinear', 'newton-cg', 'lbfgs', 'sag', 'saga']
params = dict(solver=solver_list)
log_reg = LogisticRegression(C=1, n_jobs=-1, random_state=34)
clf = GridSearchCV(log_reg, params, cv=5)
clf.fit(x_train, y_train)

lr=LogisticRegression(n_jobs=-1,random_state=34,solver='lbfgs')
lr.fit(x_train,y_train)

# Saving model to disk
pickle.dump(lr, open('jithu.pkl','wb'))