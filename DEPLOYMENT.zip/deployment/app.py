from flask import Flask,render_template,url_for,request
from flask_bootstrap import Bootstrap
from flask_sqlalchemy import SQLAlchemy
import pandas as pd 
import numpy as np 

# ML Packages
from sklearn.feature_extraction.text import CountVectorizer
import joblib
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import GridSearchCV


app = Flask(__name__)
bootstrap=Bootstrap(app)
db=	 SQLAlchemy(app)


@app.route('/')
@app.route('/index')
def index():
	return render_template('index.html')

@app.route('/predict', methods=['POST','GET'])
def predict():
	
	df= pd.read_csv("indian_liver_patient.csv")

	#changing values 1&2 to )&1 respectively

	df['is_patient']=np.where((df.is_patient== int(1)),int(0), df.is_patient)
	df['is_patient']= np.where((df.is_patient==int(2)),int(1),df.is_patient)
	df['is_patient']=df['is_patient'].apply(pd.to_numeric)

	#droping duplicates
	df=df.drop_duplicates()

	#fill with mean vlaues
	mean_value=df['alkphos'].mean()
	df['alkphos']= df['alkphos'].fillna(mean_value)

	#converting continuos to numerical values
	dummy= pd.get_dummies(df['gender'])
	df=pd.concat([df,dummy], axis=1)
	df=df.drop('gender', axis=1)



	# Receives the input query from form
	if request.method == 'POST':
		age=request.form.get("age",False)
		female=request.form.get("female",False)
		male=request.form.get("male",False)
		tot_bilrubin=request.form.get("tot_bilrubin",False)
		direct_bilrubin=request.form.get("direct_bilrubin",False)
		tot_protien=request.form.get("tot_protien",False)
		albumin=request.form.get("albumin",False)
		ag_ratio=request.form.get("ag_ratio",False)
		sgpt=request.form.get("sgpt",False)
		sgot=request.form.get("sgot",False)
		alkphos=request.form.get("alkphos",False)
		data = [age,female,male,tot_bilrubin,direct_bilrubin,tot_protien,albumin,ag_ratio,sgpt,sgot,alkphos,]
		clean_data=[float(i) for i in data]
		ex1=np.array(clean_data).reshape(1,-1)
		logit_model = joblib.load('data/jithu.pkl')
		result_prediction = logit_model.predict(ex1)
	return render_template('result.html',prediction = result_prediction)


if __name__ == '__main__':
	app.run(debug=True)